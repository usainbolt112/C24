var dustbin
var ground
var crumpledpaper

function setup() {
  createCanvas(400, 400);

  dustbin = createSprite(200,50,240,100)
  dustbin.addImage("dustbin",redbox.svg)
  
  ground=createSprite(200,50,400,20)
  
  crumpledpaper=createSprite(50,70,40,40);
}

function draw() {
  background(220);
  if(keyDown(UP_ARROW)){
  crumpledpaper.velocityY=2}
  if(keyDown(RIGHT_ARROW)){
  crumpledpaper.velocityX=2}
  crumpledpaper.collide(dustbin)
}